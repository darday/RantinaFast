<div>
        <!-- Navigation -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" >
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <img src="assets/img/Logo_Horizontal.png" alt="" height="50%" width="25%">
                </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
            <!-- <li class="nav-item active">
                <a class="nav-link" href="#">Home
                        <span class="sr-only">(current)</span>
                    </a>
                </li>-->
                <li class="nav-item">
                <a class="nav-link" href="index.php">INICIO</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="nosotros.php">NOSOTROS</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="noticias.php">NOTICIAS</a>
                </li>
                <li class="nav-item">
                
                <li class="nav-item">
                <a class="nav-link" href="tiendas.php">TIENDAS</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="contacto.php">CONTACTOS</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="indexlog.php">
                    <button type="button" class="btn btn-success" style="margin-top: -9px; margin-bottom: - 2px;">INGRESAR</button> 
                </a>
                </li>
                <li class="nav-item">
                
                </li>
            </ul>
            </div>
        </div>
        </nav>
    </div>