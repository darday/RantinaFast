<BR>

<BR>

<BR>
<BR>
<BR>




<div class=" footer">

  <!-- Footer Links -->
  <div class="container text-center text-md-left">

    <!-- Footer links -->
    <div class="row text-center text-md-left ">

      <!-- Grid column 
      <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
        <h6 class="text-uppercase mb-4 font-weight-bold">Company name</h6>
        <p>Here you can use rows and columns to organize your footer content. Lorem ipsum dolor sit amet,
          consectetur
          adipisicing elit.</p>
      </div>-->
      
      <div class="col-md-12 col-lg-12 col-xl-12 col-xl-12 " style="color:white">
        <h6 class="text-uppercase mb-4 font-weight-bold" >Contacto</h6>        
      </div>
      
        <div class=" col-md-6 col-lg-6  col-xl-6 " style="color:white">       
            <i class="fa fa-map-marker" style="color:white"></i>   Juan de Velasco 2060 y Guayaquil / Riobamba - Ecuador<br>        
            <i class="fa fa-envelope"  style="color:white"></i> rantinafast@gmail.com <br>       
        </div>
        <div class=" col-md-4 col-lg-6 col-xl-6 col-xl-6 " style="color:white">
                    
            <i class="fa fa-phone"  style="color:white"></i> (03) 2943168 <br>       
            <i class="fa fa-phone"  style="color:white"></i> 0992774388 – 0939212520
        </div>

      <!-- Grid column -->

    </div>
    <!-- Footer links -->

   <br>
    

  </div>
  <!-- Footer Links -->

</div>

	<script src="css/jsindex.js"></script>
	<script src="js/jsindex.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="https://cdn.ckeditor.com/4.12.1/standard/ckeditor.js"></script>
	<script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="js/jquery-1.10.2.js"></script>
	