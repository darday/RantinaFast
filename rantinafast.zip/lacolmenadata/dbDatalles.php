<?php
    $hostname = 'localhost';
    $database = 'rantinafast';
    $username = 'root';
    $password = '';
?>